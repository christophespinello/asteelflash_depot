#!/usr/bin/python3

import serial
import threading
import queue 
import configparser
import logging

INIFILENAME = './noCOMM.ini'
_logging = logging.getLogger(__name__)

class noCOMMThread(threading.Thread):

    def __init__(self, queue):
        threading.Thread.__init__(self)
        self.queue = queue

        config = configparser.ConfigParser()
        config.read(INIFILENAME)

        self.port = config['noCOMM']['comport']
        self.json_filename = config['noCOMM']['json_filename']
        
    def run(self):
        test_end_frame = False
        s = ''
        while True:
            s=''

    def send_frame(self, s):
        _logging.debug('send frame :' + s)
    
    def close(self) :    
        _logging.debug('close communicaiton port')
