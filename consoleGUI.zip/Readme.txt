Commandes ConsoleGUI

Dans consoleGUI.ini :
	- frame_type = NO_COMM
	- frame_type = IHK_UART
	- frame_type = WRP_UART
	- frame_type = WRP_NFC

Fichier json

Etiquette 	: ":LOOP"
Goto		: "GOTO LOOP"
Sleep		: "SLEEP 10"

Mise à zéro fichier logfile
		: "LOGFILE START"
Enregistrement datas 
		: "LOGFILE RECORD" 
		: 1ere r�ponse de la commande suivante
Enregistrement fichier
		: LOGFILE WRITE 

https://www.dropbox.com/oauth2/authorize?response_type=token&redirect_uri=https://www.dropbox.com/1/oauth2/display_token&client_id=lfcdeiwk5im7rw1

