#!/usr/bin/python3

import serial
import threading
import queue 
import configparser
import logging
import time

from WRPnfcFrame import generateNFCframe, decryptNFCframe

INIFILENAME = './WRPnfc.ini'

_logging = logging.getLogger(__name__)

class WRPnfcThread(threading.Thread):

    def __init__(self, queue):
        threading.Thread.__init__(self)
        self.queue = queue

        config = configparser.ConfigParser()
        config.read(INIFILENAME)

        self.port = config['WRPnfc']['comport']
        self.debit = int(config['WRPnfc']['baudrate'])
        self.json_filename = config['WRPnfc']['json_filename']
        self.kmob = config['WRPnfc']['kmob']
        self.serialPort = serial.Serial(self.port,self.debit,timeout=1)
        
        self.EUID = ''
        self.counter = 23481
        
        self.wait_for_answer = False
        
    def run(self):
        while True:
            end_read_serial = False
            answer = ''
            while (not end_read_serial) :
                answer = answer + self.serialPort.read(1).decode('utf-8')
                if (len(answer) == 0) :
                    end_read_serial = True
                elif (answer[-1] == '\r') :
                    end_read_serial = True
                    
            if (len(answer) != 0) :
                answer = answer[0:-1]
                analyse_answer = answer.split(':')
                if (analyse_answer[0] == 'NFC') :
                    self.queue.put(decryptNFCframe(self.EUID,analyse_answer[1],self.kmob))
                if (analyse_answer[0] == 'EUID') :
                    self.EUID = analyse_answer[1]
                    #self.queue.put('EUID : ' + self.EUID)
                if (analyse_answer[0] == 'PULSES') :
                    self.queue.put('PULSES signal : ' + analyse_answer[1] + ' - OK')
                if (analyse_answer[0] == 'DIRECTION') :
                    self.queue.put('DIRECTION signal : ' + analyse_answer[1] + ' - OK')
                if (analyse_answer[0] == 'FAULT') :
                    self.queue.put('FAULT signal : ' + analyse_answer[1] + ' - OK')
                    

    def send_frame(self, s):
        s_split = s.split(' ')
        
        if (s_split[0] == 'send_io_command') :
            if (len(s_split) >= 2) :
                data_frame = ''
                for i in range (1,len(s_split)) :
                    data_frame = data_frame + s_split[i] + ' '
                data_frame = data_frame[0:-1]     
                frame = data_frame
#                self.queue.put(self.sendIOCommand(frame))
                self.sendIOCommand(frame)
                return
            else :
                _logging.error('send_io_command bad number of arguments')
                return
        
        self.EUID = self.getEUID()
        
        time.sleep(1)
        
        if (self.EUID == None) :
            self.queue.put('NO TAG')
            _logging.info('NO TAG')
            return

        if (s_split[0] == 'send_nfc_write_parameter') :
            if (len(s_split) == 3) :
                data_frame = ''
                for i in range (1,len(s_split)) :
                    data_frame = data_frame + s_split[i]
                frame = generateNFCframe(self.EUID, self.counter,'01',data_frame, self.kmob )
                self.sendCommand(frame)
            else :
                _logging.error('send_nfc_write_parameter bad number of arguments')
                return

        if (s_split[0] == 'send_nfc_read_parameter') :
            if (len(s_split) == 2) :
                data_frame = ''
#                for i in range (1,len(s_split)) :
#                    data_frame = data_frame + s_split[i]
                frame = generateNFCframe(self.EUID, self.counter,'00',data_frame, self.kmob )
                self.sendCommand(frame)
            else :
                _logging.error('send_nfc_read_parameter bad number of arguments')
                return

        if (s_split[0] == 'send_nfc_command') :
            if (len(s_split) == 2) :
                data_frame = ''
#                for i in range (1,len(s_split)) :
#                    data_frame = data_frame + s_split[i]
                frame = generateNFCframe(self.EUID, self.counter,s_split[1],data_frame, self.kmob )
                self.sendCommand(frame)
            else :
                _logging.error('send_nfc_read_parameter bad number of arguments')
                return
            
        if (s_split[0] == 'send_nfc_7f_command') :
            if (len(s_split) >= 2) :
                data_frame = ''
                for i in range (1,len(s_split)) :
                    data_frame = data_frame + s_split[i] + ' '
                data_frame= data_frame[0:-1]
                frame = generateNFCframe(self.EUID, self.counter, '7F', data_frame, self.kmob )
                self.sendCommand(frame)
            else :
                _logging.error('send_nfc_7f_command bad number of arguments')
                return
    
    def close(self) :    
        self.serialPort.close()
        
    def getEUID(self):
        self.serialPort.write(str.encode('get_euid\r'))
             
    def sendCommand(self,frame):
        frame = 'send_nfc_frame '+ frame + '\r'
        self.serialPort.write(str.encode(frame))
        time.sleep(1)
        return

    def sendIOCommand(self,frame):
        frame = frame + '\r'
        self.serialPort.write(str.encode(frame))
        return
       
