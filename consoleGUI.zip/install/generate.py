#!/usr/bin/python3
# -*- coding: utf-8 -*-

import configparser
import os
import shutil
import zipfile 
import dropbox

INIFILENAME = './generate.ini'

config = configparser.ConfigParser()
config.read(INIFILENAME)

name = config['GENERATE']['application']
filelist = config['GENERATE']['filelist']
TOKEN = config['GENERATE']['TOKEN']

with open('../' + name + '.VERSION', 'r') as version : 
    VERSION = version.readline().replace('\n','')
version.close()

try:
    shutil.rmtree('./' + name)
except OSError as e:
    print('No directory')
    
def zipfolder(foldername, target_dir):            
    zipobj = zipfile.ZipFile(foldername + '.zip', 'w', zipfile.ZIP_DEFLATED)
    rootlen = len(target_dir) + 1
    for base, dirs, files in os.walk(target_dir):
        for file in files:
            fn = os.path.join(base, file)
            zipobj.write(fn, fn[rootlen:])

with open(filelist, 'r') as files:
    filenames = [filenames.strip() for filenames in files.readlines()]
    
os.mkdir('./' + name)

for file in filenames:
    temp_dir = file.split('/')
    if (len(temp_dir) > 1) :
        try:
            os.mkdir('./' + name +'/' + temp_dir[len(temp_dir)-2])
        except OSError as error:
            i=1 
    shutil.copyfile('../' + file, './' + name + '/' + file)
    print('File ' + file, './' + name + '/' + file +' copied')

zipfolder(name,name)
print('Generate ' + name +'.zip')

dbx = dropbox.Dropbox(TOKEN)
#print(dbx.users_get_current_account())

with open(name + '.zip', 'rb') as f:
    result = dbx.files_upload(f.read(), '/' + name + '/' + name + '.zip',mode=dropbox.files.WriteMode("overwrite"))
    print('File ' + name + '.zip uploaded to dropbox account')
    result = dbx.files_upload(f.read(), '/' + name + '/' + name + ' ' + VERSION + '.zip',mode=dropbox.files.WriteMode("overwrite"))
    print('File ' + name + ' ' + VERSION + '.zip' + ' uploaded to dropbox account')

os.remove(name + '.zip')

try:
    shutil.rmtree('./' + name)
except OSError as e:
    print('Directory removed')
