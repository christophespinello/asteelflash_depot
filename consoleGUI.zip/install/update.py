#!/usr/bin/python3
# -*- coding: utf-8 -*-

import configparser
import os
import zipfile 
import dropbox

INIFILENAME = './generate.ini'

config = configparser.ConfigParser()
config.read(INIFILENAME)

name = config['GENERATE']['application']
token = config['GENERATE']['TOKEN']

print('Update from Dropbox')

dbx = dropbox.Dropbox(token)
with open('./' + name + '.zip', "wb") as f:
    metadata, res = dbx.files_download(path='/' + name + '/' + name + '.zip')
    f.write(res.content)

print('Updated from Dropbox')
    
zip_ref = zipfile.ZipFile('./' + name + '.zip') # create zipfile object

with zipfile.ZipFile('./' + name + '.zip', 'r') as zip_ref:
   # Get a list of all archived file names from the zip
   listOfFileNames = zip_ref.namelist()
   # Iterate over the file names
   for fileName in listOfFileNames:
       # Check filename endswith csv
       if not (fileName.endswith('.ini')) :
           # Extract a single file from zip
           print(zip_ref.extract(fileName, './' + name + '/' ))
           

os.remove('./' + name + '.zip')